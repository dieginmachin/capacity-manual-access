---
name: capacity-calculator
description: The Capacity Manual, chapter 01 install. Measures a design team's real capacity from its task tool. It counts unique designs (not rows) per business day for the whole team, and works out cost per email from the team's monthly cost. Use when someone asks how many designs or emails their team ships, their capacity, output per day, cost per email or design, whether to hire another designer, or wants a baseline before changing their process. Works from a ClickUp CSV export, from tasks pulled through the ClickUp MCP, or from any task list with a name and a done date.
---

# Capacity Calculator

From The Capacity Manual, chapter 01: Capacity = Systems × Standards.

This skill turns a task export into one honest number: **unique designs per business day, for the team**. From that it works out **cost per email**:

> cost per email = monthly design cost / (designs per business day × working days)

Cost and working days are fixed. Designs per day is the only input a system can move. That's why the manual spends its time on the denominator, not on hiring.

## Rules (from the manual, never break them)

1. **Count unique designs, not rows.** A task title that repeats is a revision, not a new design. The script deduplicates by normalised task name and keeps the first finish date.
2. **Divide by business days,** Monday to Friday, minus any holidays the user gives you.
3. **Team numbers.** Report per person only when the export clearly supports it. If one account sits on most tasks, say so and give the team number only. The script checks this for you.
4. **Results, not goals.** A goal said out loud isn't output delivered. Only report what the export shows.
5. **No borrowed numbers.** Never compare the result to industry averages or another studio's output. The only comparison is the user's own earlier baseline.
6. **Correlation, not cause.** When comparing with a baseline, name what else changed in between. Don't claim a system caused the change.

## Workflow

### 1. Get the tasks

Ask which applies, then follow that path:

- **ClickUp MCP is connected.** Find the space that holds the design tasks (the hierarchy tool), then pull finished tasks with the filter tool, using `date_closed_from` and `date_closed_to` for the window (usually last month) and asking for `status` and `assignees`. Results come about 100 at a time, so **keep requesting the next page until `has_more` is false**. Save every task object to `tasks.json` as `{"tasks": [...]}`.
  ClickUp leaves `date_closed` empty on tasks in "complete"-type statuses even when they match the date filter. So run the script with `--from`, `--to` and **`--undated-in-window`**: the window you filtered by is the date. For a month-by-month view, pull and run one month at a time.
- **A ClickUp export.** In ClickUp, open the List or Space view → ⋯ → Export → CSV, with all columns. Ask the user to attach the file.
- **Another tool** (Asana, Monday, Trello, a sheet). Any CSV works if it has a task name column and a done date column. Pass `--title-col` and `--date-col` if the names differ.

Ask two more things:
- Which statuses mean finished, if theirs aren't standard. Default: complete, closed, done, approved, delivered.
- The monthly cost of the people in the export, if they want cost per email. One total number is enough. Never guess it.

### 2. Run the calculator

```bash
python3 scripts/capacity.py tasks.csv --from 2026-10-01 --to 2026-10-31 --monthly-cost 9000 --save-baseline capacity-baseline.json
```

From the ClickUp MCP (no done dates in the result):

```bash
python3 scripts/capacity.py tasks.json --from 2026-10-01 --to 2026-10-31 --undated-in-window --strip "^follow up " --monthly-cost 9000
```

Useful options:
- `--done-status "complete,client approved"` sets which statuses count, or `any` to skip the status check.
- `--holidays 2026-11-26,2026-11-27` leaves holidays out of business days.
- `--strip " v\d+$" --strip " \(revision\)" --strip "^follow up "` collapses revision markers before deduplicating. Before running, scan the task names for prefixes or suffixes the team adds to a repeat of the same email (for example "FOLLOW UP", "v2", "revision") and strip those.
- `--baseline capacity-baseline.json` compares with the last saved run.
- `--json` returns machine-readable output.

If the script stops with a column error, read the columns it lists, pick the right ones with the user, and run it again with the `--*-col` flags.

### 3. Report

Lead with the one number, in the user's words:

> Your team finished **N unique designs** in **B business days**: **X per business day**. At a monthly cost of C, that's **Y per email**.

Then show:
- the monthly table from the script
- the cost table ("if designs per day were…"), to show that the denominator is the lever
- the per person section exactly as the script phrases it
- how many rows were revisions, so the user sees why the count is lower than their row count

Close with the manual's instruction: **write the baseline down before you change anything.** Offer to save the markdown report as `capacity-baseline.md` next to the JSON.

### 4. Next time

Run again with `--baseline capacity-baseline.json`. Report the change in designs per business day, and ask what changed in between: new templates, a new hire, a quiet month. Follow rule 6.

## What raises the denominator

If the user asks what to do next, point to the manual's chapters (and their installs), not generic advice:
- Templates first (02): removes the blank canvas
- Email Layers (03): removes the "whose file is this" tax
- Atomic Emails (04) and Template Remix 625 (05): approved parts become new layouts
- Template Prepping System (06): removes the wait for copy
- 90/10 (07): AI drafts, the designer judges
- The checklist (08): removes rework after export
- Brand context files (09): the same feedback never arrives twice
- DFY OS 2.0 (11): removes the admin around all of it

See `references/chapter-01.md` for the chapter's own wording.
