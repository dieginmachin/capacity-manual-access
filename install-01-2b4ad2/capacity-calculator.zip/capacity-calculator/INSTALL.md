# Capacity Calculator: install guide

The Capacity Manual, chapter 01 install. One number before you change anything: **unique designs per business day, for your team**, and what each email costs you.

## What's in the folder
- `SKILL.md`: the instructions Claude follows
- `scripts/capacity.py`: the calculator (Python, no extra packages)
- `references/chapter-01.md`: chapter 01 in brief, so Claude explains results the way the manual does
- `examples/sample-tasks.csv`: example data to try it on (not real numbers)

## Install

**In the Claude app (claude.ai or desktop)**
1. Open Settings → Capabilities, and make sure code execution is on.
2. Under Skills, choose Upload skill and pick `capacity-calculator.zip`.
3. Start a new chat and say: "Run my capacity baseline", then attach your task export.

**In Claude Code**
1. Unzip into your skills folder: `~/.claude/skills/capacity-calculator/`
2. In any project, ask: "Run my capacity baseline on tasks.csv".

## Get your tasks out of ClickUp
- **Export:** open the List or Space with your design tasks → ⋯ → Export → CSV, all columns. Last month is a good first window.
- **ClickUp MCP:** if ClickUp is connected to Claude, just say "pull last month's finished design tasks from ClickUp and run my capacity baseline".

Any other tool works if the CSV has a task name and a done date.

## Try it first
Ask Claude: "Run the capacity calculator on the example tasks with a monthly cost of 9000." Or run it yourself:

```
python3 scripts/capacity.py examples/sample-tasks.csv --monthly-cost 9000
```

## What you'll get
- Unique designs, rows, and how many rows were revisions
- Designs per business day for the team, by month
- Cost per email, and what it would be at more designs per day
- Per person numbers only when your export supports them
- A saved baseline to compare against next month

Every number comes from your own export. No industry averages.
